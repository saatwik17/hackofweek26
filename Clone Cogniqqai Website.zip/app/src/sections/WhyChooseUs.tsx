import { useEffect, useRef, useState } from 'react';
import { Shield, TrendingUp, Brain, Heart, CheckCircle } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'High-Trust Engineering',
    description: 'Research-backed methods with transparent communication.',
    color: 'from-blue to-cyan',
  },
  {
    icon: TrendingUp,
    title: 'Built for Scale',
    description: 'Your product grows without breaking.',
    color: 'from-purple to-pink',
  },
  {
    icon: Brain,
    title: 'Gen AI Expertise',
    description: 'Deep experience with LLMs and custom AI.',
    color: 'from-orange to-red',
  },
  {
    icon: Heart,
    title: 'User-Centered Design',
    description: 'Every feature is intuitive and purposeful.',
    color: 'from-green to-teal',
  },
];

const additionalPoints = [
  'End-to-end AI development',
  'Continuous optimization',
  'Dedicated support team',
  'Proven track record',
];

export default function WhyChooseUs() {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="why-us"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-blue/5 to-black" />
        {/* Grid Pattern */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span
            className={`inline-block text-blue font-medium text-sm uppercase tracking-widest mb-4 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Why Choose Us
          </span>
          <h2
            className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-1000 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Passion for precision,
            <br />
            <span className="text-gradient-purple">commitment to quality</span>
          </h2>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`group relative transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              <div
                className={`relative h-full glass-card rounded-2xl p-6 transition-all duration-500 overflow-hidden ${
                  hoveredIndex === index
                    ? 'bg-white/10 scale-[1.02]'
                    : hoveredIndex !== null
                    ? 'opacity-50'
                    : ''
                }`}
              >
                {/* Gradient Background on Hover */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
                />

                {/* Icon */}
                <div
                  className={`relative w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.color} p-[1px] mb-5`}
                >
                  <div className="w-full h-full rounded-2xl bg-black/80 flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                </div>

                {/* Content */}
                <h3 className="font-display text-xl font-semibold text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-white/60 text-sm leading-relaxed">
                  {feature.description}
                </p>

                {/* Decorative Corner */}
                <div
                  className={`absolute -bottom-4 -right-4 w-24 h-24 rounded-full bg-gradient-to-br ${feature.color} opacity-10 blur-2xl transition-all duration-500 ${
                    hoveredIndex === index ? 'scale-150 opacity-20' : ''
                  }`}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info Section */}
        <div
          className={`glass-card rounded-3xl p-8 lg:p-12 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
          style={{ transitionDelay: '600ms' }}
        >
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Left - Image Area */}
            <div className="relative">
              <div className="aspect-video rounded-2xl overflow-hidden bg-gradient-to-br from-purple/20 to-blue/20">
                <div className="w-full h-full flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple to-blue flex items-center justify-center animate-pulse-glow">
                      <Shield className="w-10 h-10 text-white" />
                    </div>
                    <span className="text-white/60 text-sm">Trusted by Industry Leaders</span>
                  </div>
                </div>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -right-4 w-16 h-16 rounded-xl bg-gradient-to-br from-purple to-pink flex items-center justify-center shadow-glow animate-float">
                <span className="text-2xl font-bold text-white">5+</span>
              </div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 rounded-xl bg-gradient-to-br from-blue to-cyan flex items-center justify-center shadow-glow-blue animate-float" style={{ animationDelay: '1s' }}>
                <span className="text-2xl font-bold text-white">99%</span>
              </div>
            </div>

            {/* Right - Content */}
            <div>
              <h3 className="font-display text-2xl lg:text-3xl font-bold text-white mb-4">
                We don't just build software,
                <br />
                <span className="text-gradient">we build partnerships</span>
              </h3>
              <p className="text-white/60 mb-6 leading-relaxed">
                Our approach goes beyond traditional development. We immerse ourselves
                in your business, understand your challenges, and become an extension
                of your team. This deep collaboration ensures solutions that truly
                align with your goals.
              </p>

              <div className="grid grid-cols-2 gap-4">
                {additionalPoints.map((point, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                    <span className="text-white/80 text-sm">{point}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
