import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Bot, Calendar, Package, Puzzle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const services = [
  {
    id: 1,
    icon: Bot,
    title: 'AI-Powered Customer Service',
    description:
      'Automate 80% of routine queries and turn your support center into a revenue driver. Our intelligent chatbots and virtual assistants provide 24/7 support with human-like understanding.',
    image: '/service-1.jpg',
    stats: '80% Automation',
  },
  {
    id: 2,
    icon: Calendar,
    title: 'Automated Scheduling & Operations',
    description:
      'Eliminate no-shows and recover thousands in lost revenue with intelligent automation. Smart scheduling that learns from patterns and optimizes for maximum efficiency.',
    image: '/service-2.jpg',
    stats: '40% Less No-Shows',
  },
  {
    id: 3,
    icon: Package,
    title: 'Intelligent Inventory Management',
    description:
      'Prevent stockouts and make data-driven decisions with predictive forecasting. Real-time insights that help you optimize stock levels and reduce holding costs.',
    image: '/service-3.jpg',
    stats: '35% Cost Reduction',
  },
  {
    id: 4,
    icon: Puzzle,
    title: 'Micro Tools & Extensions',
    description:
      'Lightweight tools powered by AI to boost productivity. From browser extensions to desktop widgets, we build solutions that integrate seamlessly into your workflow.',
    image: '/service-4.jpg',
    stats: '3x Productivity',
  },
];

export default function Services() {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-black via-purple/5 to-black" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span
            className={`inline-block text-purple font-medium text-sm uppercase tracking-widest mb-4 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Our Services
          </span>
          <h2
            className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-1000 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Solve your biggest challenges with{' '}
            <span className="text-gradient">end-to-end AI solutions</span>
          </h2>
          <p
            className={`text-lg text-white/60 transition-all duration-1000 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            From strategy to deployment, we deliver comprehensive AI solutions
            tailored to your unique business needs.
          </p>
        </div>

        {/* Service Cards */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <div
              key={service.id}
              className={`group relative overflow-hidden rounded-3xl transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{
                transitionDelay: `${300 + index * 100}ms`,
                perspective: '1000px',
              }}
              onMouseEnter={() => setHoveredCard(service.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div
                className="relative h-full glass-card overflow-hidden transition-all duration-500 group-hover:bg-white/10"
                style={{
                  transform:
                    hoveredCard === service.id
                      ? 'rotateX(2deg) rotateY(-2deg) translateZ(10px)'
                      : 'rotateX(0) rotateY(0) translateZ(0)',
                }}
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
                  
                  {/* Stats Badge */}
                  <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-purple/80 backdrop-blur-sm text-white text-xs font-medium">
                    {service.stats}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 lg:p-8">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple/20 to-blue/20 flex items-center justify-center flex-shrink-0 group-hover:from-purple/30 group-hover:to-blue/30 transition-colors">
                      <service.icon className="w-6 h-6 text-purple-light" />
                    </div>
                    <h3 className="font-display text-xl lg:text-2xl font-semibold text-white leading-tight">
                      {service.title}
                    </h3>
                  </div>

                  <p className="text-white/60 mb-6 leading-relaxed">
                    {service.description}
                  </p>

                  <button className="inline-flex items-center text-purple-light hover:text-white font-medium transition-colors group/btn">
                    Learn more
                    <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>

                {/* Hover Glow Effect */}
                <div
                  className={`absolute inset-0 rounded-3xl transition-opacity duration-500 pointer-events-none ${
                    hoveredCard === service.id ? 'opacity-100' : 'opacity-0'
                  }`}
                  style={{
                    background:
                      'radial-gradient(circle at 50% 50%, rgba(79, 17, 255, 0.15), transparent 70%)',
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div
          className={`mt-12 text-center transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
          style={{ transitionDelay: '800ms' }}
        >
          <Button
            onClick={() => scrollToSection('#contact')}
            className="group bg-gradient-to-r from-purple to-blue hover:from-purple-light hover:to-blue-light text-white font-medium px-8 py-6 rounded-full transition-all duration-300 hover:shadow-glow"
          >
            View all Services
            <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  );
}
