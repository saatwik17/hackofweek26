import Navigation from '@/sections/Navigation';
import Hero from '@/sections/Hero';
import About from '@/sections/About';
import Services from '@/sections/Services';
import WhyChooseUs from '@/sections/WhyChooseUs';
import Process from '@/sections/Process';
import CTA from '@/sections/CTA';
import Footer from '@/sections/Footer';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <Navigation />
      <main>
        <Hero />
        <About />
        <Services />
        <WhyChooseUs />
        <Process />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}

export default App;
