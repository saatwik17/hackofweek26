import { useEffect, useRef, useState } from 'react';
import { Search, PenTool, Code, Rocket } from 'lucide-react';

const steps = [
  {
    number: '01',
    icon: Search,
    title: 'Discovery & Strategy',
    description:
      'We dive deep into your business challenges, conducting thorough research and analysis to design a strategic AI roadmap tailored to your goals.',
    details: ['Stakeholder interviews', 'Market analysis', 'Technical assessment', 'Roadmap planning'],
  },
  {
    number: '02',
    icon: PenTool,
    title: 'Design & Prototype',
    description:
      'Transform ideas into visual concepts with detailed wireframes and interactive prototypes that bring your vision to life before development begins.',
    details: ['User research', 'UI/UX design', 'Interactive prototypes', 'Design system creation'],
  },
  {
    number: '03',
    icon: Code,
    title: 'Development & Testing',
    description:
      'Our engineering team builds your solution with cutting-edge technologies, backed by rigorous testing and continuous collaboration throughout.',
    details: ['Agile development', 'Code reviews', 'Automated testing', 'CI/CD pipeline'],
  },
  {
    number: '04',
    icon: Rocket,
    title: 'Launch & Growth',
    description:
      'Deploy with confidence and optimize for continued success. We provide ongoing support and iteration to ensure lasting impact.',
    details: ['Production deployment', 'Performance monitoring', 'User training', 'Continuous optimization'],
  },
];

export default function Process() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [lineProgress, setLineProgress] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setLineProgress(100);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  return (
    <section
      id="process"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-black via-purple/5 to-black" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span
            className={`inline-block text-purple font-medium text-sm uppercase tracking-widest mb-4 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Our Process
          </span>
          <h2
            className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-1000 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            From concept to creation,
            <br />
            <span className="text-gradient">seamlessly</span>
          </h2>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical Line - Desktop */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px bg-white/10 -translate-x-1/2">
            <div
              className="absolute top-0 left-0 w-full bg-gradient-to-b from-purple to-blue transition-all duration-2000 ease-out"
              style={{ height: `${lineProgress}%` }}
            />
          </div>

          {/* Steps */}
          <div className="space-y-12 lg:space-y-0">
            {steps.map((step, index) => (
              <div
                key={index}
                className={`relative lg:grid lg:grid-cols-2 lg:gap-8 ${
                  index % 2 === 0 ? '' : 'lg:direction-rtl'
                } transition-all duration-700 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${300 + index * 150}ms` }}
                onMouseEnter={() => setActiveStep(index)}
                onMouseLeave={() => setActiveStep(null)}
              >
                {/* Content */}
                <div
                  className={`${
                    index % 2 === 0
                      ? 'lg:text-right lg:pr-16'
                      : 'lg:col-start-2 lg:pl-16'
                  }`}
                >
                  <div
                    className={`glass-card rounded-2xl p-6 lg:p-8 transition-all duration-500 ${
                      activeStep === index ? 'bg-white/10' : ''
                    }`}
                  >
                    {/* Step Number */}
                    <div
                      className={`font-display text-5xl lg:text-6xl font-bold text-gradient opacity-20 mb-4 ${
                        index % 2 === 0 ? 'lg:ml-auto' : ''
                      }`}
                    >
                      {step.number}
                    </div>

                    <div className="flex items-start gap-4 mb-4">
                      <div
                        className={`w-12 h-12 rounded-xl bg-gradient-to-br from-purple to-blue flex items-center justify-center flex-shrink-0 ${
                          index % 2 === 0 ? '' : 'lg:order-2'
                        }`}
                      >
                        <step.icon className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="font-display text-xl lg:text-2xl font-semibold text-white">
                        {step.title}
                      </h3>
                    </div>

                    <p className="text-white/60 mb-6 leading-relaxed">
                      {step.description}
                    </p>

                    {/* Details */}
                    <div className="flex flex-wrap gap-2">
                      {step.details.map((detail, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 rounded-full text-xs bg-white/5 text-white/70"
                        >
                          {detail}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Center Node - Desktop */}
                <div className="hidden lg:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center">
                  <div
                    className={`relative w-16 h-16 rounded-full bg-black border-2 border-purple flex items-center justify-center transition-all duration-500 ${
                      activeStep === index ? 'scale-125 shadow-glow' : ''
                    }`}
                  >
                    <span className="font-display text-lg font-bold text-white">
                      {step.number}
                    </span>
                    {/* Pulse Ring */}
                    <div
                      className={`absolute inset-0 rounded-full border-2 border-purple transition-all duration-500 ${
                        activeStep === index ? 'scale-150 opacity-0' : 'scale-100 opacity-50'
                      }`}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
