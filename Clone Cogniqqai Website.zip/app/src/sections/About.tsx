import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Shield, Zap, Users, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';

const features = [
  {
    icon: Shield,
    title: 'Trust First',
    description: 'Transparent processes and clear communication',
  },
  {
    icon: Zap,
    title: 'Rapid Delivery',
    description: 'Agile methodologies for faster time-to-market',
  },
  {
    icon: Users,
    title: 'Expert Team',
    description: 'World-class AI engineers and researchers',
  },
  {
    icon: Target,
    title: 'Results Driven',
    description: 'Focused on measurable business outcomes',
  },
];

export default function About() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div
        className="absolute inset-0 z-0 opacity-30"
        style={{
          backgroundImage: 'url(/about-bg.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-black via-black/95 to-black" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Column - Large Text */}
          <div
            className={`transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
            }`}
          >
            <div className="relative">
              {/* Large Background Text */}
              <span className="absolute -top-8 -left-4 text-[120px] sm:text-[180px] lg:text-[220px] font-display font-black text-white/[0.03] leading-none select-none">
                ABOUT
              </span>
              
              <div className="relative">
                <span className="inline-block text-purple font-medium text-sm uppercase tracking-widest mb-4">
                  About Us
                </span>
                <h2 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
                  Engineering
                  <br />
                  <span className="text-gradient-purple">Trust.</span>
                  <br />
                  Delivering
                  <br />
                  <span className="text-gradient">Intelligence.</span>
                </h2>
              </div>
            </div>
          </div>

          {/* Right Column - Content */}
          <div
            className={`transition-all duration-1000 delay-200 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
            }`}
          >
            <p className="text-lg text-white/70 mb-8 leading-relaxed">
              At <span className="text-white font-medium">CogniQQ AI</span>, we
              don't just develop features, we build <span className="text-blue">full-scale AI systems</span>{' '}
              designed for clarity, transparency, and long-term growth. From startups to
              enterprises, we partner with teams that want to innovate without
              compromising on <span className="text-white font-medium">quality</span>.
            </p>

            <p className="text-white/60 mb-10 leading-relaxed">
              Our research-backed methods ensure that every solution we deliver is
              built to scale, secure by design, and optimized for performance. We
              believe in transparent communication, rigorous testing, and continuous
              collaboration throughout the development lifecycle.
            </p>

            <Button
              onClick={() => scrollToSection('#services')}
              className="group bg-gradient-to-r from-purple to-blue hover:from-purple-light hover:to-blue-light text-white font-medium px-8 py-6 rounded-full transition-all duration-300 hover:shadow-glow"
            >
              Know more about Us
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </div>

        {/* Feature Cards */}
        <div className="mt-20 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`group glass-card rounded-2xl p-6 hover:bg-white/10 transition-all duration-500 hover:scale-[1.02] ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${400 + index * 100}ms` }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple/20 to-blue/20 flex items-center justify-center mb-4 group-hover:from-purple/30 group-hover:to-blue/30 transition-colors">
                <feature.icon className="w-6 h-6 text-purple-light" />
              </div>
              <h3 className="font-display font-semibold text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-white/60">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
