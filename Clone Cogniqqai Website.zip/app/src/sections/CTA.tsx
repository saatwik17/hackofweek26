import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CTA() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-black via-purple/10 to-black" />

      {/* Animated Particles */}
      <div className="absolute inset-0 z-[1] overflow-hidden pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-purple-light rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${4 + Math.random() * 4}s`,
              opacity: 0.3 + Math.random() * 0.4,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Badge */}
        <div
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <Sparkles className="w-4 h-4 text-purple-light" />
          <span className="text-sm text-white/80">Unlock AI Potential</span>
        </div>

        {/* Heading */}
        <h2
          className={`font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 transition-all duration-1000 delay-100 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          Ready to transform
          <br />
          <span className="text-gradient">Your Workflow?</span>
        </h2>

        {/* Subtext */}
        <p
          className={`max-w-2xl mx-auto text-lg text-white/60 mb-10 transition-all duration-1000 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          Let's build a clear, actionable roadmap to solve your biggest operational
          challenges with AI. Schedule a free strategy session with our experts today.
        </p>

        {/* CTA Buttons */}
        <div
          className={`flex flex-col sm:flex-row items-center justify-center gap-4 transition-all duration-1000 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <Button
            onClick={() => scrollToSection('#services')}
            className="group bg-gradient-to-r from-purple to-blue hover:from-purple-light hover:to-blue-light text-white font-medium px-10 py-7 rounded-full text-lg transition-all duration-300 hover:shadow-glow hover:scale-105"
          >
            Book a Strategy Call
            <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>

          <Button
            variant="outline"
            onClick={() => scrollToSection('#services')}
            className="group border-white/20 bg-white/5 hover:bg-white/10 text-white font-medium px-10 py-7 rounded-full text-lg transition-all duration-300 hover:border-white/40"
          >
            Explore Solutions
          </Button>
        </div>

        {/* Trust Badges */}
        <div
          className={`mt-16 flex flex-wrap items-center justify-center gap-8 transition-all duration-1000 delay-400 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {['ISO 27001 Certified', 'SOC 2 Compliant', 'GDPR Ready', 'HIPAA Compatible'].map(
            (badge, index) => (
              <div
                key={index}
                className="flex items-center gap-2 text-white/40 text-sm"
              >
                <div className="w-2 h-2 rounded-full bg-green-400" />
                {badge}
              </div>
            )
          )}
        </div>
      </div>
    </section>
  );
}
