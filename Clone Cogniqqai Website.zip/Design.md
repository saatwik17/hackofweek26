# CogniQQ AI Website Design

## Overview
- **Motion Style**: Fluid Kinetic Futurism
- **Animation Intensity**: Ultra-Dynamic
- **Technology Stack**: WebGL (Three.js), GSAP (ScrollTrigger, Flip), Lenis (Smooth Scroll), CSS Houdini

## Brand Foundation
- **Colors**: 
  - Primary: #4f11ff (Vibrant Purple), #3898ec (Bright Blue)
  - Secondary: #f795bf (Pink), #794547 (Maroon), #922b21 (Dark Red)
  - Neutrals: #000000, #ffffff, #f3f3f3, #828282, #e2e2e2
- **Typography**: 
  - Display: "Poppins" (Weights: 100-900)
  - Body: "Inter" (Weights: 400, 500)
- **Core Message**: Intelligent, scalable AI solutions for the next generation.
- **Font URLs**: `https://fonts.googleapis.com/css?family=Inter:regular,500|Poppins:100,200,300,regular,500,600,700,800,900`

## Global Motion System

### Animation Timing
- **Easing Library**: 
  - `custom-expo`: `cubic-bezier(0.16, 1, 0.3, 1)` (Crisp, snappy)
  - `custom-fluid`: `cubic-bezier(0.4, 0, 0, 1)` (Smooth, flowing)
- **Duration Scale**: 
  - Micro-interactions: 0.3s
  - Entrances: 0.8s - 1.2s
  - Page Transitions: 1.0s
- **Stagger Patterns**: 0.05s per character for text, 0.1s per element for lists

### Continuous Effects
- **Section-Specific Effects**: 
  - Hero: "Data Stream" shader background
  - Footer: "Digital Noise" texture animation
- **Purposeful Motion**: Elements breathe (subtle scale/opacity) when idle to indicate interactivity.
- **Living Textures**: Subtle grain overlay on solid backgrounds to prevent banding and add filmic quality.

### Scroll Engine
- **Smooth Scroll**: Damping factor 0.1 for weight.
- **Velocity Reactivity**: Elements skew slightly (max 5deg) based on scroll speed.
- **Parallax**: Multi-plane depth system (Background: 0.1x speed, Content: 1.0x, Floating Elements: 1.5x).

## Section 1: Navigation

### Layout
**"Glassmorphic Command Bar"**
- **Structure**: Floating capsule layout (max-width 1200px) centered at top.
- **Behavior**: Morphs into a "pill" shape on scroll, expanding to full width on hover.
- **Z-Index**: 999 (Always on top).

#### Spatial Composition
- **Flex**: Space-between alignment.
- **Backdrop**: `backdrop-filter: blur(12px)` with `rgba(0,0,0,0.6)` background.
- **Border**: 1px solid `rgba(255,255,255,0.1)`.

### Content
- **Logo**: CogniQQ (SVG)
- **Links**: Home, About Us, Services, Our Lab, Blogs, Contact Us
- **CTA**: "Book a Strategy Call"

### Motion Choreography

#### Entrance Sequence
| Element | Animation | Values | Duration | Delay | Easing |
|---------|-----------|--------|----------|-------|--------|
| Navbar | Slide Down | Y: -100% → 0% | 0.8s | 0s | custom-expo |
| Links | Fade + Slide | Y: -20px → 0, Opacity: 0 → 1 | 0.4s | 0.2s (stagger) | custom-expo |

#### Interaction Effects
- **Magnetic Links**: Links attract to cursor within 50px radius (CSS transform).
- **Glow State**: Active link has a moving gradient underline.
- **Menu Open**: Hamburger lines morph into 'X' with elastic rotation.

## Section 2: Hero

### Layout
**"Immersive Data Void"**
- **Concept**: A deep, 3D space where the user feels suspended in data.
- **Structure**: Full viewport height (100dvh).
- **Composition**: Centralized typography with "orbiting" interactive elements.

#### Spatial Composition
- **Text Layer**: Absolute center, z-index 2.
- **Background Layer**: WebGL Canvas (Shader), z-index 0.
- **Floating Layer**: Interactive "particles" or "data points", z-index 1.

### Content
- **Headline**: "Building Intelligent, scalable AI solutions for the Next Generation"
- **Subtext**: "Your premier AI & Software engineering partner - transforming ideas into reliable, high-performance products."
- **Buttons**: "Explore our services", "Book a Strategy Call"

### Images
**Hero Background**
- **Resolution**: 1920x1080
- **Aspect Ratio**: 16:9
- **Transparent Background**: No (Opaque black)
- **Visual Style**: Abstract digital tech with neon cyan and violet lines.
- **Subject**: Horizontal flowing lines with dots.
- **Color Palette**: Black, Neon Cyan, Violet.
- **Generation Prompt**: "Abstract tech background, black, flowing horizontal neon cyan lines with evenly spaced glowing dots, scattered violet lines, minimalist, futuristic, digital data stream visualization, dark mode aesthetic, high contrast, modern, clean design."

### Motion Choreography

#### Entrance Sequence
| Element | Animation | Values | Duration | Delay | Easing |
|---------|-----------|--------|----------|-------|--------|
| Headline | Split-Char Reveal | Y: 100% → 0% (masked) | 1.0s | 0.2s | custom-expo |
| Subtext | Fade Up | Y: 20px → 0, Opacity: 0 → 1 | 0.8s | 0.6s | custom-fluid |
| Buttons | Scale In | Scale: 0.8 → 1, Opacity: 0 → 1 | 0.6s | 0.8s | custom-expo |

#### Scroll Effects
| Trigger | Element | Effect | Start | End | Values |
|---------|---------|--------|-------|-----|--------|
| Scroll | Headline | Parallax | Top | Bottom | Y: 0 → 150px |
| Scroll | Background | Zoom | Top | Bottom | Scale: 1 → 1.1 |

#### Continuous Animations
- **Background**: "Digital Aurora" shader - slow-moving, generative gradient noise in deep blues and purples (replacing static image but matching its vibe).
- **Text**: Subtle "breathing" weight animation (font-weight 600 ↔ 700).

#### Interaction Effects
- **Mouse Parallax**: Text moves slightly opposite to cursor (X/Y translate max 20px).
- **Button Hover**: "Liquid Fill" effect - button fills with a wave animation from the cursor entry point.

### Advanced Effects

#### Shader Effects
- **Hero Background**: Custom GLSL fragment shader rendering smooth, organic noise patterns (Perlin/Simplex) in the brand colors (#4f11ff, #3898ec) against deep black.
- **Distortion**: Mouse movement creates a "warp" field in the shader, displacing the noise like ripples in water.

## Section 3: About Us

### Layout
**"Typographic Architecture"**
- **Concept**: Text as the primary structural element.
- **Structure**: Asymmetric split. Left side: Massive, vertical "ABOUT US" text (masked). Right side: Content.
- **Innovation**: The "ABOUT US" text is fixed (sticky) on the left, while content scrolls on the right.

#### Spatial Composition
- **Left Column**: 30% width, Sticky position.
- **Right Column**: 70% width, flowing content.
- **Masking**: The large "ABOUT US" text acts as a window (mask) for a subtle moving texture.

### Content
- **Label**: "About Us"
- **Heading**: "Engineering Trust. Delivering Intelligence."
- **Body**: "At Cogniq AI, we don't just develop features, we build full-scale AI systems designed for clarity, transparency, and long-term growth. From startups to enterprises, we partner with teams that want to innovate without compromising on quality."
- **Button**: "Know more about Us"

### Images
**About Background Pattern**
- **Resolution**: 1920x1080
- **Aspect Ratio**: 16:9
- **Transparent Background**: No (Solid black)
- **Visual Style**: Abstract geometric grid, minimalist.
- **Subject**: Large hollow circles, intersecting thin lines.
- **Color Palette**: Black, White, Light Gray.
- **Generation Prompt**: "Minimalist abstract background, solid black, large hollow white circles, intersecting thin white lines forming grid pattern, geometric, modern, clean, futuristic, monochrome, high contrast."

### Motion Choreography

#### Scroll Effects
| Trigger | Element | Effect | Start | End | Values |
|---------|---------|--------|-------|-----|--------|
| Scroll | "ABOUT US" Mask | Texture Shift | Enter | Exit | Background-position: 0% → 100% |
| Scroll | Body Text | Highlight | Enter | Center | Color: #555 → #FFF |

#### Interaction Effects
- **Button Magnetic**: Standard magnetic pull with cursor.
- **Text Hover**: Words in the body text have a `data-weight` attribute; hovering increases font-weight smoothly (Variable font axis animation if supported, otherwise scale).

## Section 4: Services

### Layout
**"3D Perspective Deck"**
- **Concept**: Cards are arranged in a 3D space, slightly rotated towards the viewer.
- **Structure**: Horizontal scroll container (on mobile) or skewed grid (desktop).
- **Innovation**: Scroll-linked rotation. As user scrolls, the cards flatten out from a tilted position.

#### Spatial Composition
- **Grid**: 2-column grid with a "stagger" (even items lower than odd).
- **Perspective**: Container has `perspective: 1000px`.

### Content
- **Heading**: "Our Services"
- **Subtext**: "Solve your biggest challenges with end-to-end AI solutions."
- **Cards**:
  1. AI-Powered Customer Service
  2. Automated Scheduling & Operations
  3. Intelligent Inventory Management
  4. Micro Tools & Extensions

### Images
**Service Card 1 - Customer Service**
- **Resolution**: 1200x800
- **Aspect Ratio**: 3:2
- **Transparent Background**: No (Solid dark)
- **Visual Style**: Futuristic abstract tech.
- **Subject**: Neon cyan/purple lines and dots.
- **Color Palette**: Black, Neon Cyan, Purple.
- **Generation Prompt**: "Futuristic abstract background, solid dark black, neon cyan and purple vertical lines with evenly spaced glowing dots, vertical cyan bar, digital data stream, high-tech, modern, clean, minimalist, glowing effect."

**Service Card 2 - Scheduling**
- **Resolution**: 1200x800
- **Aspect Ratio**: 3:2
- **Transparent Background**: No (Solid black)
- **Visual Style**: Abstract geometric.
- **Subject**: Concentric circles/hexagons.
- **Color Palette**: Black, Neon Cyan, Blue, Purple.
- **Generation Prompt**: "Abstract geometric background, black, concentric circles and hexagons, neon cyan and blue gradient lines, grid pattern, futuristic, digital, high-tech, modern, minimalist, glowing effect."

**Service Card 3 - Inventory**
- **Resolution**: 1200x800
- **Aspect Ratio**: 3:2
- **Transparent Background**: No (Solid black)
- **Visual Style**: Abstract geometric.
- **Subject**: Vertical lines, hexagonal patterns.
- **Color Palette**: Black, Neon Blue, Purple.
- **Generation Prompt**: "Abstract geometric background, solid black, vertical blue lines with glowing dots, hexagonal pattern, neon blue and purple accents, futuristic digital tech, minimalist, modern, clean."

**Service Card 4 - Micro Tools**
- **Resolution**: 1200x800
- **Aspect Ratio**: 3:2
- **Transparent Background**: No (Solid black)
- **Visual Style**: Abstract geometric.
- **Subject**: Concentric hexagons, grid.
- **Color Palette**: Black, Neon Cyan, Blue.
- **Generation Prompt**: "Abstract geometric background, solid black, concentric neon cyan hexagons, grid pattern, vertical cyan lines, futuristic, minimalist, digital tech, high contrast, modern."

### Motion Choreography

#### Entrance Sequence
| Element | Animation | Values | Duration | Delay | Easing |
|---------|-----------|--------|----------|-------|--------|
| Cards | 3D Flip Up | RotateX: 45deg → 0, Opacity: 0 → 1 | 0.8s | 0.1s (stagger) | custom-expo |

#### Scroll Effects
| Trigger | Element | Effect | Start | End | Values |
|---------|---------|--------|-------|-----|--------|
| Scroll | Card Images | Parallax | Enter | Exit | Y: -20px → 20px |

#### Interaction Effects
- **Card Hover**: **"Holographic Lift"**. Card lifts (Z-axis translate), border glows (animated gradient), and the internal image zooms slightly while a "glare" effect moves across the surface.
- **Tilt**: 3D tilt on hover (max 10deg) following cursor.

## Section 5: Why Choose Us

### Layout
**"Orbital Feature System"**
- **Concept**: Features orbit around a central "Trust" statement.
- **Structure**: Central text acts as the gravity well. Features are positioned absolutely around it in a semi-circle.
- **Innovation**: On scroll, the features rotate along the arc into view.

#### Spatial Composition
- **Center**: "Why Choose Us" heading.
- **Orbit**: Features positioned at 30, 60, 90, 120, 150 degrees.

### Content
- **Heading**: "Why Choose Us"
- **Subtext**: "Passion for precision, commitment to quality."
- **Features**:
  1. High-Trust Engineering
  2. Built for Scale
  3. Gen AI Expertise
  4. User-Centered Design

### Motion Choreography

#### Scroll Effects
| Trigger | Element | Effect | Start | End | Values |
|---------|---------|--------|-------|-----|--------|
| Scroll | Feature Orbit | Rotation | Enter | Exit | Rotate: 0deg → 45deg |

#### Interaction Effects
- **Feature Hover**: The hovered item scales up (1.2x) and moves to the foreground (z-index boost), while others dim slightly (opacity 0.5).
- **Icon Animation**: The circular icon background pulses (scale 1 ↔ 1.1) continuously.

## Section 6: Process

### Layout
**"The Timeline Path"**
- **Concept**: A visible, glowing line connects the steps.
- **Structure**: Vertical zig-zag layout.
- **Innovation**: The connecting line draws itself (SVG stroke-dashoffset) as the user scrolls. Steps "light up" (activate) when the line reaches them.

#### Spatial Composition
- **Line**: Central SVG path.
- **Nodes**: Steps alternating left/right of the line.

### Content
- **Heading**: "Our Process"
- **Subtext**: "From concept to creation, seamlessly."
- **Steps**: 01. Discovery & Strategy, 02. Design & Prototype, 03. Development & Testing, 04. Launch & Growth

### Motion Choreography

#### Scroll Effects
| Trigger | Element | Effect | Start | End | Values |
|---------|---------|--------|-------|-----|--------|
| Scroll | Connecting Line | Draw Path | Top | Bottom | Stroke-dashoffset: 100% → 0% |
| Scroll | Step Number | Count Up | Enter | Center | Opacity: 0.2 → 1 |

#### Interaction Effects
- **Step Hover**: The step node expands, revealing a "tooltip" with a short description of that phase.

## Section 7: CTA & Footer

### Layout
**"The Event Horizon"**
- **Concept**: A massive, immersive footer that feels like entering a digital space.
- **Structure**: CTA merges into Footer.
- **Innovation**: **"Curtain Reveal"**. The footer is fixed at the bottom (z-index -1), and the previous section scrolls *up* to reveal it (like a curtain rising).

#### Spatial Composition
- **CTA**: Large, centered typography.
- **Footer Grid**: 4-column asymmetric grid.

### Content
- **CTA**: "Ready to transform Your Workflow?", "Let's build a clear, actionable roadmap..."
- **Footer**: Logo, Company Links, AI Solutions, Services, Products, Legal.

### Images
**Footer Background**
- **Resolution**: 1920x1080
- **Aspect Ratio**: 16:9
- **Transparent Background**: No (Solid black)
- **Visual Style**: Abstract geometric, tech-inspired.
- **Subject**: Grid pattern, circles, lines.
- **Color Palette**: Black, White, Light Gray.
- **Generation Prompt**: "Minimalist abstract background, solid black, thin white intersecting lines forming grid, large hollow white circles, diagonal lines, geometric, modern, futuristic, monochrome, high contrast, tech-inspired."

### Motion Choreography

#### Scroll Effects
| Trigger | Element | Effect | Start | End | Values |
|---------|---------|--------|-------|-----|--------|
| Scroll | Footer | Reveal | Bottom-100px | Bottom | Parallax Reveal |

#### Continuous Animations
- **Footer Background**: The grid pattern slowly pans/moves diagonally (infinite loop).
- **Noise Overlay**: Subtle film grain (opacity 0.05) animates over the footer.

#### Interaction Effects
- **Link Hover**: "Strikethrough-Reappear" effect. Line crosses through text, text disappears, reappears from center.

## Technical Implementation Notes

### Required Libraries
- **Three.js**: For the Hero shader background.
- **GSAP (GreenSock)**: Core animation engine (ScrollTrigger, Flip plugin).
- **Lenis**: For buttery smooth scrolling (essential for parallax sync).
- **SplitType**: For text splitting animations.

### Critical Performance Rules
- ✅ **WebGL Canvas**: Single canvas instance in background, changing scenes via shader uniforms.
- ✅ **Will-Change**: Apply `will-change: transform` only during active scroll states.
- ✅ **Debounce**: Resize observers must be debounced (100ms).
- ❌ **No Layout Thrashing**: Read layout values once, write style updates in a batch (GSAP handles this well).
- ❌ **Limit Filters**: Use backdrop-filter sparingly (only on Navbar).

### Browser Support
- **Progressive Enhancement**: Shader effects fall back to high-quality static images on low-power devices (detected via `hardwareConcurrency` or FPS monitor).
- **Reduced Motion**: If `prefers-reduced-motion: reduce` is detected, all parallax and zoom effects disable, fading to simple opacity transitions.
